"use client";
import Form_layout from "../layout/form_layout";
import { ArrowRight, Eye, EyeClosed, LockKeyhole } from "lucide-react";
import { EntryZone } from "../../../_components/shared/entry";
import { Controller, useForm } from "react-hook-form";
import {
  ResetPasswordSchema,
  ResetPasswordSchemaType,
} from "@/app/(auth)/forgotPassword/schema/forgotPassword.schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAuth } from "@/hooks/useAuth";
import { useForgotPasswordStore } from "../../_store/forgotPassword.store";
import { useState } from "react";
import { toast } from "sonner";

export default function NewPassword({ OnClick }: { OnClick: () => void }) {
  // ! States
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const email = useForgotPasswordStore((state) => state.email);
  const otp = useForgotPasswordStore((state) => state.otp);
  const setPassword = useForgotPasswordStore((state) => state.setPassword);

  const form = useForm<ResetPasswordSchemaType>({
    resolver: zodResolver(ResetPasswordSchema),
    mode: "onChange",
    defaultValues: {
      password: "",
      confirmPassword: "",
    },
  });

  // ! Functions
  const { resetPassword } = useAuth();

  const handleReset = async (data: ResetPasswordSchemaType) => {
    const password = data.password;
    toast.loading("Mise à jour du mot de passe...", { id: "password-reset" });
    try {
      await resetPassword.mutateAsync({
        email,
        otp,
        password,
      });

      setPassword(data.password);
      toast.success("Votre mot de passe a été changé avec succès.", {
        id: "password-reset",
      });
      OnClick();
    } catch (error) {
      toast.error(
        "Le mot de passe n'a pas pu être changé. Le code est peut-être expiré.",
        {
          id: "password-reset",
        },
      );
      console.error(error);
    }
  };

  // ! Render
  return (
    <Form_layout title="Nouveau mot de passe" icon={LockKeyhole}>
      <form onSubmit={form.handleSubmit(handleReset)} className="space-y-5">
        <Controller
          name="password"
          control={form.control}
          render={({ field, fieldState }) => (
            <EntryZone
              placeholder="********"
              label="Nouveau mot de passe"
              fieldState={fieldState}
              field={field}
              icon={LockKeyhole}
              type={showPassword ? "text" : "password"}
              icon2={
                <span onClick={() => setShowPassword(!showPassword)}>
                  {showPassword ? (
                    <Eye className="size-5" />
                  ) : (
                    <EyeClosed className="size-5" />
                  )}
                </span>
              }
            />
          )}
        />
        <Controller
          name="confirmPassword"
          control={form.control}
          render={({ field, fieldState }) => (
            <EntryZone
              placeholder="********"
              label="Confirmer le mot de passe"
              field={field}
              fieldState={fieldState}
              icon={LockKeyhole}
              type={showConfirmPassword ? "text" : "password"}
              icon2={
                <span
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  {showConfirmPassword ? (
                    <Eye className="size-5" />
                  ) : (
                    <EyeClosed className="size-5" />
                  )}
                </span>
              }
            />
          )}
        />
        <button
          type="submit"
          disabled={resetPassword.isPending}
          className="btn btn-primary flex h-12 w-full items-center justify-center gap-2"
        >
          {resetPassword.isPending
            ? "Réinitialisation..."
            : "Réinitialiser le mot de passe"}
          <ArrowRight className="size-5" />
        </button>
      </form>
    </Form_layout>
  );
}
